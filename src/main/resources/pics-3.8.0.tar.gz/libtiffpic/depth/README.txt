These sample TIFF image files are prepared by Bob Friesenhahn
<bfriesen@simple.dallas.tx.us> using a development version of
GraphicsMagick 1.2.

See the file summary.txt for a description of the images.

These files are hereby placed in the public domain.


